﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServiceAutomation.JwtToken
{
    public class RootNode
    {
        public string token { get; set; }
    }
}

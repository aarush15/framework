# RestSharpFramework

Framework for testing RESTful Services with RestSharp and C# HTTP Client

## Course Link (Discount Coupon)

https://www.udemy.com/course/rest-api-automation-with-restsharp-http-client/

## YouTube Playlist

- **RestSharp** https://www.youtube.com/playlist?list=PLlsKgYi2Lw73ox9LF5VfYMrA1eo9e7rIq

- **Selenium Webdriver** https://www.youtube.com/playlist?list=PLlsKgYi2Lw724ozNSmdSrrtU8q6a1m3ob

- **C# HttpClient** https://www.youtube.com/playlist?list=PLlsKgYi2Lw722PMqESdivKJQgRtJAdbzn

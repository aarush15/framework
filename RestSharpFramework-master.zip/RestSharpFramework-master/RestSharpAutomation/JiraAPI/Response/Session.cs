﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestSharpAutomation.JiraAPI.Response
{
    public class Session
    {
        public string name { get; set; }
        public string value { get; set; }
    }
}

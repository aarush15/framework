﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestSharpAutomation.Question.Model
{
    public class LdiMarkups
    {
        public int additionalProp1 { get; set; }
        public int additionalProp2 { get; set; }
        public int additionalProp3 { get; set; }
    }
}
